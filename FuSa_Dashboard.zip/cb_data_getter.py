import re
import logging

from CommonAPI.cb_api import CBAPI


class CbDataGetter():
    def __init__(self, configData):
        self.cb_api = CBAPI(self.get_baseURL(configData['cb']),
                            configData['cb']['username'],
                            configData['cb']['password'])

        self.latestReleaseName = None
        self.parentAndHasReleaseNameTestRunItems = list()


    def get_baseURL(self, cbConfigData):
        if not "baseUrl" in cbConfigData:
            baseUrl = "http://vccb.lge.com:8080/cb/rest"
        else:
            baseUrl = cbConfigData['baseUrl']

        return baseUrl


    def set_reqConfigData(self, configData, level):
        self.reqConfigData = configData['req'][level]


    def set_testConfigData(self, configData, level):
        self.testConfigData = configData['test'][level]



    def get_requirementTrackers(self):
        trackers = list()
        reqTrackers = list()

        if 'trackers' in self.reqConfigData:
            for trackerId in self.reqConfigData['trackers']:
                trackers.append(self.cb_api.get_tracker("/project/" + self.reqConfigData['projectId'], trackerId))
        else:
            trackers = self.cb_api.get_tracker("/project/" + self.reqConfigData['projectId'], "type=Requirement")

        reqTrackers = trackers

        return reqTrackers


    def get_requirementItems(self, requirementTrackers, criteria):
        requirementItems = list()

        for tracker in requirementTrackers:
            requirementItems += self.cb_api.get_specificitems(tracker['uri'], "and", criteria, "pagesize=500")

        return requirementItems


    def set_totalRequirementCount_Gen11(self, criteria, reqLevel):

        self.specoutRequirementCount = 0                # TR_REQ_TOTAL 에 포함 안됨
        self.defineRequirementCount = 0                 # TR_REQ_DEFINE
        self.reviewRequirementCount = 0                 # TR_REQ_REVIEW
        self.approvedRequirementCount = 0               # TR_REQ_AGREED

        self.totalRequirementCount = 0                  # TR_REQ_TOTAL
        self.etcRequirementCount = 0                    # TR_REQ_TOTAL 에서 other status

        requirementTrackers = self.get_requirementTrackers()

        requirementItems = self.get_requirementItems(requirementTrackers, criteria)

        print(len(requirementItems))
        print(reqLevel)

        totalRequirementItems = list()

        if reqLevel == 'swSR':

            for requirementItem in requirementItems:
                if "children" in requirementItem:
                    for child in requirementItem['children']:
                        totalRequirementItems.append(child['uri'])
                else:
                    totalRequirementItems.append(requirementItem['uri'])

            for totalRequirementItem in totalRequirementItems:
                item = self.cb_api.get_item(totalRequirementItem)
                if "status" in item:
                    self.totalRequirementCount += 1

                    if item['status']['name'] == "Spec Out":
                        self.specoutRequirementCount += 1
                    elif item['status']['name'] == "Approved":
                        self.approvedRequirementCount += 1
                    elif item['status']['name'] == "Review":
                        self.reviewRequirementCount += 1
                    elif item['status']['name'] == "Define":
                        self.defineRequirementCount += 1
                    else:
                        self.etcRequirementCount += 1
                else:
                    print("No status field in Item")

            self.totalRequirementCount -= self.specoutRequirementCount


        else:       # hsiSR or tscSR

            for requirementItem in requirementItems:
                if "children" in requirementItem:
                    for child in requirementItem['children']:
                        totalRequirementItems.append(child['uri'])

            items = list()

            for totalRequirementItem in totalRequirementItems:
                item = self.cb_api.get_item(totalRequirementItem)
                if "children" in item:
                    for grandchild in item['children']:
                        items.append(grandchild['uri'])
                else:
                    items.append(item['uri'])

            sub_item = list()

            for item in items:
                sub_item = self.cb_api.get_item(item)
                if "testItem" in sub_item:
                    if sub_item['testItem'] == True:

                        self.totalRequirementCount += 1

                        if sub_item['status']['name'] == "Spec Out":
                            self.specoutRequirementCount += 1
                        elif sub_item['status']['name'] == "Approved":
                            self.approvedRequirementCount += 1
                        elif sub_item['status']['name'] == "Review":
                            self.reviewRequirementCount += 1
                        elif sub_item['status']['name'] == "Define":
                            self.defineRequirementCount += 1
                        else:
                            self.etcRequirementCount += 1
                    else:
                        print("No testItem field in Item")



    def set_totalRequirementCount_V2IPC(self, criteria, reqLevel):

        self.specoutRequirementCount = 0                # TR_REQ_TOTAL 에 포함 안됨
        self.defineRequirementCount = 0                 # TR_REQ_DEFINE
        self.reviewRequirementCount = 0                 # TR_REQ_REVIEW
        self.approvedRequirementCount = 0               # TR_REQ_AGREED

        self.totalRequirementCount = 0                  # TR_REQ_TOTAL
        self.etcRequirementCount = 0                    # TR_REQ_TOTAL 에서 other status

        self.totalestimatedTC = 0

        requirementTrackers = self.get_requirementTrackers()

        requirementItems = self.get_requirementItems(requirementTrackers, criteria)

        # print(len(requirementItems))
        # print(reqLevel)

        totalRequirementItems = list()

        if reqLevel == 'swSR':

            for requirementItem in requirementItems:
                if "children" in requirementItem:
                    for child in requirementItem['children']:
                        totalRequirementItems.append(child['uri'])
                else:
                    totalRequirementItems.append(requirementItem['uri'])

            for totalRequirementItem in totalRequirementItems:
                item = self.cb_api.get_item(totalRequirementItem)
                if "status" in item:
                    self.totalRequirementCount += 1

                    if item['status']['name'] == "Spec Out":
                        self.specoutRequirementCount += 1
                    elif item['status']['name'] == "Approved":
                        self.approvedRequirementCount += 1
                    elif item['status']['name'] == "Review":
                        self.reviewRequirementCount += 1
                    elif item['status']['name'] == "Define":
                        self.defineRequirementCount += 1
                    else:
                        self.etcRequirementCount += 1
                else:
                    print("No status field in Item")

                try:
                    if item['status']['name'] != "Spec Out" and item['estimatedTC'] >= 1:
                        self.totalestimatedTC += item['estimatedTC']
                    else:
                        self.totalestimatedTC += 1
                except:
                    self.totalestimatedTC += 1


            self.totalRequirementCount -= self.specoutRequirementCount


        else:       # hsiSR or tscSR

            for requirementItem in requirementItems:
                if "children" in requirementItem:
                    for child in requirementItem['children']:
                        totalRequirementItems.append(child['uri'])

            items = list()

            for totalRequirementItem in totalRequirementItems:
                item = self.cb_api.get_item(totalRequirementItem)
                if "children" in item:
                    for grandchild in item['children']:
                        items.append(grandchild['uri'])
                else:
                    items.append(item['uri'])

            sub_item = list()

            for item in items:
                sub_item = self.cb_api.get_item(item)
                if "testItem" in sub_item:
                    if sub_item['testItem'] == True:

                        self.totalRequirementCount += 1

                        if sub_item['status']['name'] == "Spec Out":
                            self.specoutRequirementCount += 1
                        elif sub_item['status']['name'] == "Approved":
                            self.approvedRequirementCount += 1
                        elif sub_item['status']['name'] == "Review":
                            self.reviewRequirementCount += 1
                        elif sub_item['status']['name'] == "Define":
                            self.defineRequirementCount += 1
                        else:
                            self.etcRequirementCount += 1
                    else:
                        print("No testItem field in Item")



    def get_totalTestcaseCount_Gen11(self):

        totalTestcaseItems = list()
        notTestcaseItems = list()
        notapprovedTestcaseItems = list()
        coveredRequirementItemsOfTestcases = list()


        self.coveredRequirementCountOfTestcases = 0      # 'TC_REQ_COVERED'

        self.totalTestcaseCount = 0                      # 'TC_TCS_TOTAL'
        self.coveredTestcaseCountOfTestcases = 0         # 'TC_TCS_COVERED'

        for testcaseTrackerId in self.testConfigData['testcaseTrackers']:
            totalTestcaseItems = self.cb_api.get_items('/tracker/' + testcaseTrackerId, "pagesize=500")

        for testcaseTrackerId in self.testConfigData['testcaseTrackers']:
            notTestcaseItems = self.cb_api.get_specificitems('/tracker/' + testcaseTrackerId, \
                    "or", "type=Information;type=Folder", "pagesize=500")
            for notTestcaseItem in notTestcaseItems:
                totalTestcaseItems.remove(notTestcaseItem)

        for totalTestcaseItem in totalTestcaseItems:
            if totalTestcaseItem['status']['name'] == 'Rejected' or totalTestcaseItem['status']['name'] == 'Deprecated':
                notapprovedTestcaseItems.append(totalTestcaseItem)

        for notapprovedTestcaseItem in notapprovedTestcaseItems:
            totalTestcaseItems.remove(notapprovedTestcaseItem)

        approvedTestcaseItems = [
            totalTestcaseItem
            for totalTestcaseItem in totalTestcaseItems
            if totalTestcaseItem['status']['name'] == 'Approved' or totalTestcaseItem['status']['name'] == 'Accepted'
        ]

        self.totalTestcaseCount = len(totalTestcaseItems)

        for totalTestcaseItem in totalTestcaseItems:
            for i in range(len(totalTestcaseItem[self.testConfigData['requirementFieldName']])):
                coveredRequirementItemsOfTestcases.append(totalTestcaseItem[self.testConfigData['requirementFieldName']][i]['name'])
                # print(totalTestcaseItem[self.testConfigData['requirementFieldName']][i]['name'])
        self.coveredRequirementCountOfTestcases = len(set(coveredRequirementItemsOfTestcases))
        self.coveredTestcaseCountOfTestcases = len(approvedTestcaseItems)



    def get_totalTestcaseCount_V2IPC(self):

        totalTestcaseItems = list()
        notTestcaseItems = list()
        notapprovedTestcaseItems = list()
        coveredRequirementItemsOfTestcases = list()


        self.coveredRequirementCountOfTestcases = 0      # 'TC_REQ_COVERED'

        self.totalTestcaseCount = 0                      # 'TC_TCS_TOTAL'
        self.coveredTestcaseCountOfTestcases = 0         # 'TC_TCS_COVERED'

        for testcaseTrackerId in self.testConfigData['testcaseTrackers']:
            totalTestcaseItems = self.cb_api.get_items('/tracker/' + testcaseTrackerId, "pagesize=500")

        for testcaseTrackerId in self.testConfigData['testcaseTrackers']:
            notTestcaseItems = self.cb_api.get_specificitems('/tracker/' + testcaseTrackerId, \
                    "or", "type=Information;type=Folder", "pagesize=500")
            for notTestcaseItem in notTestcaseItems:
                totalTestcaseItems.remove(notTestcaseItem)

        for totalTestcaseItem in totalTestcaseItems:
            if totalTestcaseItem['status']['name'] == 'Rejected' or totalTestcaseItem['status']['name'] == 'Deprecated':
                notapprovedTestcaseItems.append(totalTestcaseItem)

        for notapprovedTestcaseItem in notapprovedTestcaseItems:
            totalTestcaseItems.remove(notapprovedTestcaseItem)

        approvedTestcaseItems = [
            totalTestcaseItem
            for totalTestcaseItem in totalTestcaseItems
            if totalTestcaseItem['status']['name'] == 'Approved' or totalTestcaseItem['status']['name'] == 'Accepted'
        ]

        self.totalTestcaseCount = len(totalTestcaseItems)

        for totalTestcaseItem in totalTestcaseItems:
            for i in range(len(totalTestcaseItem[self.testConfigData['requirementFieldName']])):
                coveredRequirementItemsOfTestcases.append(totalTestcaseItem[self.testConfigData['requirementFieldName']][i]['name'])
                # print(totalTestcaseItem[self.testConfigData['requirementFieldName']][i]['name'])
        self.coveredRequirementCountOfTestcases = len(set(coveredRequirementItemsOfTestcases))
        self.coveredTestcaseCountOfTestcases = len(approvedTestcaseItems)




    def get_testRunTrackers(self):
        if 'testrunTrackers' in self.testConfigData:
            testrunTrackers = list()
            for trackerId in self.testConfigData['testrunTrackers']:
                testrunTrackers.append(self.cb_api.get_tracker("", trackerId))
            return testrunTrackers
        else:
            return self.cb_api.get_trackers("/project/" + self.testConfigData['projectId'], "type=Test Run")



    def set_parentAndHasReleaseNameTestRunItems(self):
        testRunTrackers = self.get_testRunTrackers()
        if len(testRunTrackers) == 0:
            logging.warning("No test run tracker.")
            return []

        items = []
        for testRunTracker in testRunTrackers:
            items += self.cb_api.get_items(testRunTracker['uri'], "pagesize=500")

        if 'releaseFieldName' in self.testConfigData:
            releaseFieldName = self.testConfigData['releaseFieldName']
        else:
            releaseFieldName = 'build'

        self.parentAndHasReleaseNameTestRunItems = [
            testRunItem
            for testRunItem in items
            if not "parent" in testRunItem and releaseFieldName in testRunItem
        ]
        print(len(self.parentAndHasReleaseNameTestRunItems))



    def set_latestReleaseName(self):
        if not 'setLatestReleaseNameMethod' in self.testConfigData:
            self.latestReleaseName = None
            return

        eval('self.' + self.testConfigData['setLatestReleaseNameMethod'] + '()')



    def set_latestReleaseNameFromBuild(self):
        # pattern = r'^[A-Z]+(\d+)'   # build pattern: X535
        # pattern = r'(\d)[.](\d+)'
        pattern = r'[0-9][.](\d+)'      # build pattern : 3.04
        r = re.compile(pattern)
        maxVersion = 0
        for item in self.parentAndHasReleaseNameTestRunItems:
            match = r.search(item['build'])
            if match is not None and len(match.groups()) == 1:
                if maxVersion < int(match.group(1)):
                    maxVersion = int(match.group(1))
                    self.latestReleaseName = item['build']
                    continue

        if self.latestReleaseName == None:
            logging.error("Can not get latest release name from test run items.")



    def get_latestParentTestRunItems(self):
        if 'releaseFieldName' in self.testConfigData and self.testConfigData['releaseFieldName'] == 'versions':
            return [
                item
                for item in self.parentAndHasReleaseNameTestRunItems
                if item['versions']['name'] == self.latestReleaseName
            ]
        else:
            return [
                item
                for item in self.parentAndHasReleaseNameTestRunItems
                if item['build'] == self.latestReleaseName
            ]


    def get_childTestRunItems(self, parentTestRunItems):
        childTestRunItems = []
        for parentTestRunItem in parentTestRunItems:
            childTestRunItems += parentTestRunItem['children']
        return childTestRunItems



    def set_executedTestRunItems(self, childTestRunItems):
        self.executedTestcaseCount = 0
        self.executedTestRunItems = list()

        for childTestRunItem in childTestRunItems:
            item = self.cb_api.get_item(childTestRunItem['uri'])
            if "result" in item:
                self.executedTestRunItems.append(item)

        self.executedTestcaseCount = len(self.executedTestRunItems)



    def get_pass_fail_count(self):
        if len(self.executedTestRunItems) == 0:
            logging.warning("No executed test run items.")
            return 0, 0

        passedTestRunItems = [
            executedTestRun
            for executedTestRun in self.executedTestRunItems
            if executedTestRun['result']['name'] == 'Passed'
        ]
        failedTestRunItems = [
            executedTestRun
            for executedTestRun in self.executedTestRunItems
            if executedTestRun['result']['name'] == 'Failed'
        ]
        return len(passedTestRunItems), len(failedTestRunItems)


    def get_testcaseItemsOfTestRunItems(self):
        if len(self.executedTestRunItems) == 0:
            logging.warning("No executed test run items.")
            return []
        testcaseItems = []
        for testRunItem in self.executedTestRunItems:
            for testcaseItem in testRunItem['testCases']:
                testcaseItems.append(self.cb_api.get_item(testcaseItem[0][0]['uri']))
        return testcaseItems


    def get_uniqueVerifiedRequirements(self, testcaseItems):
        if len(testcaseItems) == 0:
            logging.warning("No testcase items.")
            return []

        verifyItems = []
        for testcaseItem in testcaseItems:
            if "verifies" in testcaseItem:
                for verify in testcaseItem['verifies']:
                    verifyItems.append(verify['uri'])
            else:
                for verify in testcaseItem[self.testConfigData['requirementFieldName']]:
                    verifyItems.append(verify['uri'])
        return set(verifyItems)
