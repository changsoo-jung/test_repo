#!/usr/bin/env python3
import pymysql
import sys
import datetime
import logging
from CommonAPI.config_parser import ConfigParser

class DataSetter:
    def __init__(self, metricData, testLevel):
        databaseConfig = ConfigParser('configs\system\infra.json').parse_config()

        self.metricData = metricData
        # self.table = testLevel.upper()
        self.table = databaseConfig['table'][testLevel]
        self.connection = None

    def connect(self):
        databaseConfig = ConfigParser('configs\system\infra.json').parse_config()
        self.connection = pymysql.connect(
            host = databaseConfig['database']['host'],
            port = databaseConfig['database']['port'],
            user = databaseConfig['database']['user'],
            password = databaseConfig['database']['password'],
            db = databaseConfig['database']['db'],
            charset = databaseConfig['database']['charset']
        )
        if self.connection.open:
            logging.info("Connected to Visualization Database")
        else:
            logging.error("Failed to connect to Visualization Database")
            sys.exit(1)

    def disconnect(self):
        if self.connection.open:
            self.connection.close()
            logging.info("Disconnected from Visualization Database")

    def deployMetric(self):
        try:
            with self.connection.cursor(pymysql.cursors.DictCursor) as cursor:
                logging.debug("Search a row that has same DATE_UPDATED and PROJECT_ID")
                sql = "SELECT * FROM " + self.table
                sql += """ WHERE PROJECT_ID = %(PROJECT_ID)s AND DATE_UPDATED = %(DATE_UPDATED)s
                           AND VERSION = %(VERSION)s LIMIT 1"""
                # sql += """ WHERE PROJECT_ID = %(PROJECT_ID)s LIMIT 10"""
                cursor.execute(sql, self.metricData)
                row = cursor.fetchall()

                if len(row) == 0:
                    logging.debug("Not exist, then insert new row")
                    self.insertRow()
                else:
                    logging.debug("Exist, then update the row that has same DATE_UPDATED and PROJECT_ID and VERSION")
                    self.deleteRow(row[0]['ID'])
                    self.insertRow()
                    # self.updateRow(row[0]['ID'])
        finally:
            self.disconnect()


    def readTable(self, tablename):
        self.connect()
        try:
            with self.connection.cursor(pymysql.cursors.DictCursor) as cursor:
                logging.debug("Search a row that has same DATE_UPDATED and PROJECT_ID")
                sql = "SELECT * FROM " + tablename
                # sql += """ WHERE PROJECT_ID = %(PROJECT_ID)s AND DATE_UPDATED >= DATE_ADD(NOW(), INTERVAL -1 DAY) order by DATE_UPDATED asc LIMIT 1000"""
                sql += """ WHERE PROJECT_ID = %(PROJECT_ID)s AND DATE_UPDATED >= DATE_ADD(NOW(), INTERVAL -1 WEEK) order by DATE_UPDATED asc LIMIT 10000"""
                cursor.execute(sql, self.metricData)
                rows = cursor.fetchall()
                if len(rows) == 0:
                    rows = self.metricData
                    ret = rows.fromkeys(rows, 0)
                else:
                    ret = rows[-1]

                return ret
        finally:
            self.disconnect()


    def readMetricData(self):
        databaseConfig = ConfigParser('configs\system\infra.json').parse_config()

        row_SWT = self.readTable(databaseConfig['table']['SWT'])
        row_HSI = self.readTable(databaseConfig['table']['HSI'])

        # print(len(row_SWT), row_SWT)
        # print(len(row_HSI), row_HSI)

        return row_SWT, row_HSI


    def insertRow(self):
        with self.connection.cursor(pymysql.cursors.DictCursor) as cursor:
            sql = "INSERT INTO " + self.table + " ("
            sortedKeys = sorted(self.metricData.keys())
            columns = ", ".join(map(str, sortedKeys))
            sql += columns + ") VALUES ("
            for key in sortedKeys:
                sql += "%(" + key + ")s,"
            sql = sql.rstrip(",")
            sql += ")"

            cursor.execute(sql, self.metricData) 
            self.connection.commit()


    def updateRow(self, id):    # UPDATE `INFRABOARD`.`FUSA_PROJECT_STATUS` SET `SYSIT_TR_REQ_TOTAL`='1' WHERE `ID`='117';
        with self.connection.cursor(pymysql.cursors.DictCursor) as cursor:
            sql = "UPDATE " + self.table + " SET "
            sortedKeys = sorted(self.metricData.keys())
            for key in sortedKeys:
                sql += key + " = %(" + key + ")s,"
            sql = sql.rstrip(",")
            sql += " WHERE ID = " + str(id)

            cursor.execute(sql, self.metricData) 
            self.connection.commit()



    def deleteRow(self, id):    # DELETE FROM `INFRABOARD`.`FUSA_PROJECT_STATUS` WHERE `ID`='117';
        with self.connection.cursor(pymysql.cursors.DictCursor) as cursor:
            sql = "DELETE FROM " + self.table + " WHERE ID = " + str(id)
            # sortedKeys = sorted(self.metricData.keys())
            # for key in sortedKeys:
            #     sql += key + " = %(" + key + ")s,"
            # sql = sql.rstrip(",")
            # sql += " WHERE ID = " + str(id)

            cursor.execute(sql, self.metricData)
            self.connection.commit()



    # def deleteRow(self, id):
    #     with self.connection.cursor(pymysql.cursors.DictCursor) as cursor:
    #         sql = "DELETE " + self.table + " SET "
    #         sortedKeys = sorted(self.metricData.keys())
    #         for key in sortedKeys:
    #             sql += key + " = %(" + key + ")s,"
    #         sql = sql.rstrip(",")
    #         sql += " WHERE ID = " + str(id)
    #
    #         cursor.execute(sql, self.metricData)
    #         self.connection.commit()

