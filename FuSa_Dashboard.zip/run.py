#!/usr/bin/env python3
import argparse
import os
import coloredlogs
import datetime
import copy


from data_getter import DataGetter
from data_setter import DataSetter

os.environ["COLOREDLOGS_LOG_FORMAT"] = "[%(asctime)s]  [%(filename)s:%(lineno)s] %(message)s"
coloredlogs.install(level='DEBUG')


def get_metricData(metricRawData, testLevel):
    metricData = {
        'PROJECT_ID': metricRawData.configData['infraDB']['project_id'],
        'ORG': metricRawData.configData['infraDB']['ORG'],
        'OEM': metricRawData.configData['infraDB']['OEM'],
        'PROJECT_NAME': metricRawData.configData['infraDB']['project_name'],
        'TEST_PHASE': metricRawData.configData['infraDB']['test_phase'],
        'ASIL': metricRawData.configData['infraDB']['ASIL'],

        'TR_REQ_TOTAL' : metricRawData.totalRequirementCount,
        'TR_REQ_DEFINE' : metricRawData.defineRequirementCount,
        'TR_REQ_REVIEW' : metricRawData.reviewRequirementCount,
        'TR_REQ_AGREED' : metricRawData.approvedRequirementCount,

        'TC_REQ_TOTAL' : metricRawData.totalRequirementCount,
        'TC_REQ_COVERED' : metricRawData.coveredRequirementCountOfTestcases,
        'TC_TCS_TOTAL' : metricRawData.totalTestcaseCount,
        'TC_TCS_COVERED' : metricRawData.coveredTestcaseCountOfTestcases,

        'TE_REQ_TOTAL' : metricRawData.totalRequirementCount,
        'TE_REQ_COVERED' : metricRawData.coveredRequirementCountOfTestexecutes,
        'TE_REQ_UNCOVERED': metricRawData.uncoveredRequirementCountOfTestexecutes,
        'TE_TE_TOTAL' : metricRawData.totalTestcaseCount,
        'TE_TE_EXE' : metricRawData.executedTestcaseCount,
        'TE_TE_PASS' : metricRawData.passCount,
        'TE_TE_FAIL' : metricRawData.failCount,
        'TE_TE_NA' : metricRawData.naCount,

        'TE_ISSUE_TOTAL' : metricRawData.issueTotalCount,
        'TE_ISSUE_OPEN' : metricRawData.issueOpenCount,
        'TE_ISSUE_INPROGRESS' : metricRawData.issueInprogressCount,
        'TE_ISSUE_CLOSED' : metricRawData.issueClosedCount,
        'DATE_UPDATED': datetime.datetime.now().strftime('%Y-%m-%d'), #'-%H-%M-%S'),
        'VERSION': metricRawData.latestReleaseName
    }
    return metricData


def get_metricData_summary(tableData_SWT, tableData_HSI):
    metricData_summary = {
        'PROJECT_ID': metricData['PROJECT_ID'],
        'ORG': metricData['ORG'],
        'OEM': metricData['OEM'],
        'PROJECT_NAME': metricData['PROJECT_NAME'],
        'TEST_PHASE': metricData['TEST_PHASE'],
        'ASIL': metricData['ASIL'],

        'SWT_TR_REQ_TOTAL' : tableData_SWT['TR_REQ_TOTAL'],
        'SWT_TR_REQ_AGREED' : tableData_SWT['TR_REQ_AGREED'],
        'SWT_TC_TCS_TOTAL' : tableData_SWT['TC_TCS_TOTAL'],
        'SWT_TC_TCS_COVERED' : tableData_SWT['TC_TCS_COVERED'],
        'SWT_TE_TE_EXE' : tableData_SWT['TE_TE_EXE'],
        'SWT_TE_TE_PASS' : tableData_SWT['TE_TE_PASS'],

        'SYSIT_TR_REQ_TOTAL': tableData_HSI['TR_REQ_TOTAL'],
        'SYSIT_TR_REQ_AGREED': tableData_HSI['TR_REQ_AGREED'],
        'SYSIT_TC_TCS_TOTAL': tableData_HSI['TC_TCS_TOTAL'],
        'SYSIT_TC_TCS_COVERED': tableData_HSI['TC_TCS_COVERED'],
        'SYSIT_TE_TE_EXE': tableData_HSI['TE_TE_EXE'],
        'SYSIT_TE_TE_PASS': tableData_HSI['TE_TE_PASS'],

        'DATE_UPDATED': datetime.datetime.now().strftime('%Y-%m-%d'), #'-%H-%M-%S'),
        'VERSION': tableData_SWT['VERSION'],
    }
    return metricData_summary


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Get raw data for FuSa Dashboard')
    parser.add_argument('-c', '--config', help='specify a config file', required=True)
    parser.add_argument('-l', '--level', help='specify a test level', choices=['SWT', 'HSI', 'TSC'], required=True)
    args = parser.parse_args()

    metricDataGetter = DataGetter(args.config, args.level)

    metricDataGetter.get_data()
    metricData = get_metricData(metricDataGetter, args.level)

    metricDataSetter = DataSetter(metricData, args.level)
    metricDataSetter.connect()
    metricDataSetter.deployMetric()
    metricDataSetter.disconnect()


    r_SWT, r_HSI = metricDataSetter.readMetricData()
    metricData_summary = get_metricData_summary(r_SWT, r_HSI)

    metricDataSetter_summary = DataSetter(metricData_summary, "project_status")
    metricDataSetter_summary.connect()
    metricDataSetter_summary.deployMetric()
    metricDataSetter_summary.disconnect()


    # metricDataGetter.print_data()
