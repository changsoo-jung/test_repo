from .rest_api import RestAPI

class CBAPI(RestAPI):
    def __init__(self, base_url, username, password):
        super(CBAPI, self).__init__(base_url, username, password)

    def get_trackers(self, project_uri, query=''):
        uri = project_uri + "/trackers?" + query
        resp = self.get(uri)
        return resp.json()

    def get_tracker(self, project_uri, trackerId):
        uri = project_uri + "/tracker/" + str(trackerId)
        resp = self.get(uri)
        return resp.json()

    def get_categories(self, project_uri, query=''):  # CMDB
        uri = project_uri + "/categories?" + query
        resp = self.get(uri)
        return resp.json()

    def get_specificitems(self, tracker_uri, logic, criteria, query):
        uri = tracker_uri + "/items/" + logic + "/" + criteria + "/page/1?" + \
            query
        resp = self.get(uri)
        json_data = resp.json()
        num_pages = json_data['total'] // json_data['size'] + 1
        specificitems = json_data['items']

        for i in range(2, num_pages + 1):
            uri = tracker_uri + "/items/" + logic + "/" + criteria + "/page/" \
                + str(i) + "?" + query
            resp = self.get(uri)
            json_data = resp.json()
            specificitems += json_data['items']

        return specificitems

    def get_item_summary(self, tracker_uri):
        uri = tracker_uri + "/item/summary"
        resp = self.get(uri)
        return resp.json()

    def get_items(self, tracker_uri, query):
        uri = tracker_uri + "/items/page/1?" + query
        resp = self.get(uri)
        json_data = resp.json()
        num_pages = json_data['total'] // json_data['size'] + 1
        items = json_data['items']

        for i in range(2, num_pages + 1):
            uri = tracker_uri + "/items/page/" + str(i) \
                    + "?" + query
            resp = self.get(uri)
            json_data = resp.json()
            items += json_data['items']

        return items

    def get_item(self, item_uri, query=''):
        uri = item_uri+query
        resp = self.get(uri)
        return resp.json()
