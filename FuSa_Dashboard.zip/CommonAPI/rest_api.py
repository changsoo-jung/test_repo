import requests
import json


class RestAPI:

    def __init__(self, base_url, username, password,
                 headers={'Content-Type': 'application/json'},
                 num_trial=3):
        self.base_url = base_url
        self.username = username
        self.password = password
        self.headers = headers
        self.num_trial = num_trial

    def put(self, uri, json_data):
        r = None
        for i in range(self.num_trial):
            try:
                r = requests.put(self.base_url+uri,
                                 data=json.dumps(json_data),
                                 auth=(self.username, self.password))
                break
            except:
                continue
        return r

    def post(self, uri, json_data):
        r = None
        for i in range(self.num_trial):
            try:
                r = requests.post(self.base_url+uri,
                                  data=json.dumps(json_data),
                                  auth=(self.username, self.password),
                                  headers=self.headers)
                break
            except:
                continue
        return r

    def get(self, uri):
        r = None
        for i in range(self.num_trial):
            try:
                r = requests.get(self.base_url+uri,
                                 auth=(self.username, self.password))
                break
            except:
                continue
        return r
