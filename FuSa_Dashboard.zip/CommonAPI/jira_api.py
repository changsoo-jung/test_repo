import requests
import json


class JiraAPI:

    baseUrl = "http://vlm.lge.com/issue/rest/api/latest/"
    headers = {
        'Content-Type': 'application/json'
    }

    def __init__(self, project_key, user_id, password):
        self.project_key = project_key
        self.user_id = user_id
        self.password = password


    def get_project_id(self):
        r = None
        for i in range(3):
            try:
                r = requests.get(self.baseUrl + "project/" + self.project_key,
                                 auth=(self.user_id, self.password))
                break
            except:
                continue

        if r is None:
            raise Exception("Request Not Working")

        if r.status_code == 200:
            project = json.loads(r.text)
            return project['id']
        else:
            raise Exception("Fail to get project from jira")

    def get_fields_info(self):
        r = requests.get(self.baseUrl + "issue/createmeta?projectKeys=" + self.project_key + "&issuetypeNames=Bug&expand=projects.issuetypes.fields",
                         auth=(self.user_id, self.password))

        if r.status_code == 200:
            return json.loads(r.text)
        else:
            print(r.text)
            raise Exception("Fail to get fields from jira")

    def create_issue(self, issue_data):
        r = None
        for i in range(3):
            try:
                r = requests.post(self.baseUrl + "issue",
                                  data=issue_data,
                                  auth=(self.user_id, self.password),
                                  headers=self.headers)
                print(r)
                print(r.text)
                break
            except:
                continue

        if r is None:
            raise Exception("Request Not Working")

        if r.status_code == 201:
            return json.loads(r.text)
        else:
            print(r.text)
            raise Exception("Fail to create issue : " + issue_data['fields']['summary'] + "\n-->" + r.text)

    def update_issue(self, issue_id, update):
        r = None
        for i in range(3):
            try:
                r = requests.put(self.baseUrl + "issue/" + str(issue_id),
                                 data=update,
                                 auth=(self.user_id, self.password),
                                 headers=self.headers)
                break
            except:
                continue

        if r is None:
            raise Exception("Request Not Working")

        if r.status_code == 204:
            print("Update Issue Success : " + str(issue_id))
            return 0, r.text
        else:
            print(r.text)
            print("Update Issue Fail : " + str(issue_id))
            return -1, r.text




    """
    [{
         'expand': 'operations,editmeta,changelog,transitions,renderedFields',
         'id': '1402302',
         'self': 'http://vlm.lge.com/issue/rest/api/latest/issue/1402302',
         'key': 'TCPXI-23211',
         'fields': {
              'summary': '[Fusa][SWT][ADC Selfcheck] MICOM did NOT reset when ADC self check is failed',
              'assignee': {
                   'self': 'http://vlm.lge.com/issue/rest/api/2/user?username=kisoo.bang',
                   'name': 'kisoo.bang',
                   'key': 'kisoo.bang',
                   'emailAddress': 'kisoo.bang@lge.com',
                   'avatarUrls': {
                        '48x48': 'http://vlm.lge.com/issue/secure/useravatar?avatarId=10122',
                        '24x24': 'http://vlm.lge.com/issue/secure/useravatar?size=small&avatarId=10122',
                        '16x16': 'http://vlm.lge.com/issue/secure/useravatar?size=xsmall&avatarId=10122',
                        '32x32': 'http://vlm.lge.com/issue/secure/useravatar?size=medium&avatarId=10122'
                   },
                   'displayName': '방기수 kisoo.bang',
                   'active': True,
                   'timeZone': 'ROK'
              },
              'status': {
                   'self': 'http://vlm.lge.com/issue/rest/api/2/status/1',
                   'description': 'The issue is open and ready for the assignee to start work on it.',
                   'iconUrl': 'http://vlm.lge.com/issue/images/icons/statuses/open.png',
                   'name': 'Open',
                   'id': '1',
                   'statusCategory': {
                        'self': 'http://vlm.lge.com/issue/rest/api/2/statuscategory/2',
                        'id': 2,
                        'key': 'new',
                        'colorName': 'blue-gray',
                        'name': 'To Do'
                   }
              }
         }
    }]
    """
    def search_issue(self, start=0, interval=50, query_filter=None):
        query = 'project=' + self.project_key

        if query_filter is not None:
            query = query + ' AND ' + query_filter

        r = None
        for i in range(3):
            try:
                r = requests.get(self.baseUrl + "search",
                                 params={
                                     "jql": query,
                                     "startAt": start,
                                     "maxResults": interval,
                                     "fields": [
                                         'status', 'summary', 'assignee'
                                         # 'summary', 'description', 'assignee'

                                     ]
                                 },
                                 auth=(self.user_id, self.password),
                                 headers=self.headers)
                break
            except:
                continue

        if r is None:
            raise Exception("Request Not Working")

        if r.status_code == 200:
            return json.loads(r.text)['issues']

        return None