import json


class ConfigParser:
    def __init__(self, file_name):
        self.file_name = file_name

    def parse_config(self):
        try:
            with open(self.file_name, 'r') as config_file:
                return json.load(config_file)
        except IOError:
            print("Could not read file" + self.file_name)
            sys.exit()
