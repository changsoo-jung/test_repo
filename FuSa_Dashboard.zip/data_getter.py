#!/usr/bin/env python3

import logging
import requests
import json

from cb_data_getter import CbDataGetter
from CommonAPI.config_parser import ConfigParser
from CommonAPI.jira_api import JiraAPI

from jira import JIRA

class DataGetter:
    def __init__(self, configFilename, testLevel):
        self.configData = ConfigParser(configFilename).parse_config()
        self.set_testLevel(testLevel)
        self.set_reqLevel()
        self.set_projectName()
        self.set_testPhase()

        # self.project_id = self.configData['infraDB']['project_id']
        self.latestReleaseName = ''

        # Testability Review
        self.totalRequirementCount = 0                  # 'TR_REQ_TOTAL'
        self.specoutRequirementCount = 0
        self.defineRequirementCount = 0                 # 'TR_REQ_DEFINE'
        self.reviewRequirementCount = 0                 # 'TR_REQ_REVIEW'
        self.approvedRequirementCount = 0               # 'TR_REQ_AGREED'
        self.etcRequirementCount = 0

        # Test Case Development
        self.coveredRequirementCountOfTestcases = 0      # 'TC_REQ_COVERED'

        self.totalTestcaseCount = 0                      # 'TC_TCS_TOTAL'
        self.coveredTestcaseCountOfTestcases = 0         # 'TC_TCS_COVERED'

        # Test Execution
        self.coveredRequirementCountOfTestexecutes = 0   # 'TE_REQ_COVERED'
        self.uncoveredRequirementCountOfTestexecutes = 0

        self.executedTestcaseCount = 0                  # 'TE_TE_EXE'
        self.paramexecutedTestcaseCount = 0             # 'TE_TE_EXE' (parameter 고려)
        self.passCount = 0                              # 'TE_TE_PASS'
        self.failCount = 0                              # 'TE_TE_FAIL'
        self.naCount = 0                                # 'TE_TE_NA'

        self.issueTotalCount = 0                        # 'TE_ISSUE_TOTAL'
        self.issueOpenCount = 0                         # 'TE_ISSUE_OPEN'
        self.issueInprogressCount = 0                   # 'TE_ISSUE_INPROGRESS'
        self.issueClosedCount = 0                       # 'TE_ISSUE_CLOSED'


    def set_testLevel(self, testLevel):
        self.testLevel = testLevel
        logging.info('Test Level: %s', self.testLevel)


    def set_reqLevel(self):
        if hasattr(self, 'testLevel') == False:
            logging.error('Not set test level. Please set test level, before set requirement level.')
            exit(-1)

        levels = {
            'SWT': 'swSR',
            'HSI': 'hsiSR',
            'TSC': 'tscSR'
        }
        self.reqLevel = levels[self.testLevel]
        logging.info('Requirement Level: %s', self.reqLevel)


    def set_projectName(self):          # FIX ME ( get project name from PMS)
        projects ={
            '390': 'Gen11_MY20_VCP_GA',
            '391': 'Gen11_MY20_TCP_GA',
            '392': 'Gen11_MY19_TCP_GB',
            '389': 'V2IPC',
            '388': 'MCTM',
            '387': 'WDC',
        }
        # self.project_name = projects[str(self.configData['infraDB']['project_id'])]
        self.project_name = projects.get(str(self.configData['infraDB']['project_id']), 'Gen11_MY20_VCP_GA')
        logging.info('Project Name: %s', self.project_name)


    def set_testPhase(self):
        phases = {
            'Not Start': 0,
            'Testability Review': 1,
            'TC Dev': 2,
            'Test Run': 3,
            'Completed': 4
        }
        self.testPhase = phases[self.configData['infraDB']['test_phase']]
        print("test phase: ", self.testPhase)



    def get_data(self):
        if self.configData['infraDB']['posting_method'] == 'Manual':
            self.get_data_manual()
        else:
            self.get_data_real()



    # self.reqLevel, self.testLevel, self.project_name 에 따라서 branch
    def get_data_real(self):
        cbDataGetter = None
        logging.info("Requirement Management system: %s", self.configData['req'][self.reqLevel]['system'])

        if self.configData['req'][self.reqLevel]['system'] == 'cb' and self.testPhase >= 1:
            if cbDataGetter == None:
                cbDataGetter = CbDataGetter(self.configData)
            cbDataGetter.set_reqConfigData(self.configData, self.reqLevel)

            if self.project_name == 'Gen11_MY20_VCP_GA' or self.project_name == 'Gen11_MY20_TCP_GA' or self.project_name == 'Gen11_MY19_TCP_GB':        # and self.reqLevel == 'swSR':
                cbDataGetter.set_totalRequirementCount_Gen11(cbDataGetter.reqConfigData['filterCriteria'], self.reqLevel)

            elif self.project_name == 'V2IPC':
                cbDataGetter.set_totalRequirementCount_V2IPC(cbDataGetter.reqConfigData['filterCriteria'], self.reqLevel)

            else:
                logging.info('Not supported project : ', self.project_name)
                exit(0)

            self.totalRequirementCount = cbDataGetter.totalRequirementCount
            self.specoutRequirementCount = cbDataGetter.specoutRequirementCount
            self.defineRequirementCount = cbDataGetter.defineRequirementCount
            self.reviewRequirementCount = cbDataGetter.reviewRequirementCount
            self.approvedRequirementCount = cbDataGetter.approvedRequirementCount
            self.etcRequirementCount = cbDataGetter.etcRequirementCount

        else:
            exit(0)




        logging.info("Test Management system: %s", self.configData['test'][self.testLevel]['system'])

        if self.configData['req'][self.reqLevel]['system'] == 'cb' and self.testPhase >= 2:
            if cbDataGetter == None:
                cbDataGetter = CbDataGetter(self.configData)
            cbDataGetter.set_testConfigData(self.configData, self.testLevel)

            # Test Case
            if self.project_name == 'Gen11_MY20_VCP_GA' or self.project_name == 'Gen11_MY20_TCP_GA' or self.project_name == 'Gen11_MY19_TCP_GB':        # TC 수는 item개수로부터 얻는다
                cbDataGetter.get_totalTestcaseCount_Gen11()
                self.totalTestcaseCount = cbDataGetter.totalTestcaseCount

            elif self.project_name == 'V2IPC':
                cbDataGetter.get_totalTestcaseCount_V2IPC()     # TC 수는 Req. 의 estimatedTC field 의 합
                self.totalTestcaseCount = cbDataGetter.totalestimatedTC

            else:
                logging.info('Not supported project : ', self.project_name)
                exit(0)

            self.coveredRequirementCountOfTestcases = cbDataGetter.coveredRequirementCountOfTestcases
            self.coveredTestcaseCountOfTestcases = cbDataGetter.coveredTestcaseCountOfTestcases



            # Test Run
            if self.testPhase >= 3:
                cbDataGetter.set_parentAndHasReleaseNameTestRunItems()
                cbDataGetter.set_latestReleaseName()

                if cbDataGetter.latestReleaseName == None:
                    # self.print_data()
                    return

                self.latestReleaseName = cbDataGetter.latestReleaseName
                childTestRunItems = cbDataGetter.get_childTestRunItems(cbDataGetter.get_latestParentTestRunItems())
                cbDataGetter.set_executedTestRunItems(childTestRunItems)

                self.executedTestcaseCount = cbDataGetter.executedTestcaseCount
                self.passCount, self.failCount = cbDataGetter.get_pass_fail_count()

                # 확인필요
                testcaseItems = cbDataGetter.get_testcaseItemsOfTestRunItems()
                uniqueVerified = cbDataGetter.get_uniqueVerifiedRequirements(testcaseItems)
                self.coveredRequirementCountOfTestexecutes = len(uniqueVerified)
                self.uncoveredRequirementCountOfTestexecutes = self.totalRequirementCount - self.coveredRequirementCountOfTestexecutes


        else:
            exit(0)



        logging.info("Issue Management system: %s", self.configData['issue'][self.testLevel]['system'])

        if self.configData['issue'][self.testLevel]['system'] == "jira":

            PROJECT_KEY = self.configData['issue'][self.testLevel]['projectKey']
            USER = self.configData['jira']['username']
            PASSWORD = self.configData['jira']['password']

            query = self.configData['issue'][self.testLevel]['filterCriteria']

            jira = JiraAPI(PROJECT_KEY, USER, PASSWORD)

            issues_total = jira.search_issue(0, 100, query)
            issues_open = jira.search_issue(0, 100, query +" and Status=Open")
            issues_closed = jira.search_issue(0, 100, query +" and Status=Closed")
            # issues_inprogress = jira.search_issue(0, 100, query +" and Status=In progress")

            try:
                self.issueTotalCount = len(issues_total)                    # 'TE_ISSUE_TOTAL'
                self.issueOpenCount = len(issues_open)                      # 'TE_ISSUE_OPEN'
                self.issueClosedCount = len(issues_closed)                  # 'TE_ISSUE_CLOSED'
                # self.issueInprogressCount = len(issues_inprogress)        # 'TE_ISSUE_INPROGRESS'

                # print(issues_open)

                # for i in range(self.issueTotalCount):
                #     print(issues_total[i]['fields']['status']['name'], issues_total[i]['key'], "|", issues_total[i]['fields']['assignee']['name'], "|", issues_total[i]['fields']['summary'])
                #     # logging.info('{} {} {}'.format(issues_total[i]['key'], issues_total[i]['fields']['assignee']['name'], issues_total[i]['fields']['summary']))

            except:
                print("JIRA System permission error")

        else:
            exit(0)



    def get_data_manual(self):
        self.totalRequirementCount = self.configData['metricData'][self.testLevel]['TR_REQ_TOTAL']
        self.specoutRequirementCount = 0
        self.defineRequirementCount = self.configData['metricData'][self.testLevel]['TR_REQ_DEFINE']
        self.reviewRequirementCount = self.configData['metricData'][self.testLevel]['TR_REQ_REVIEW']
        self.approvedRequirementCount = self.configData['metricData'][self.testLevel]['TR_REQ_AGREED']
        self.etcRequirementCount = 0

        # Test Case Development
        self.coveredRequirementCountOfTestcases = self.configData['metricData'][self.testLevel]['TC_REQ_COVERED']

        self.totalTestcaseCount = self.configData['metricData'][self.testLevel]['TC_TCS_TOTAL']
        self.coveredTestcaseCountOfTestcases = self.configData['metricData'][self.testLevel]['TC_TCS_COVERED']

        # Test Execution
        self.coveredRequirementCountOfTestexecutes = self.configData['metricData'][self.testLevel]['TE_REQ_COVERED']
        self.uncoveredRequirementCountOfTestexecutes = self.configData['metricData'][self.testLevel]['TE_REQ_UNCOVERED']

        self.executedTestcaseCount = self.configData['metricData'][self.testLevel]['TE_TE_EXE']
        self.paramexecutedTestcaseCount = 0
        self.passCount = self.configData['metricData'][self.testLevel]['TE_TE_PASS']
        self.failCount = self.configData['metricData'][self.testLevel]['TE_TE_FAIL']
        self.naCount = self.configData['metricData'][self.testLevel]['TE_TE_NA']

        self.issueTotalCount = self.configData['metricData'][self.testLevel]['TE_ISSUE_TOTAL']
        self.issueOpenCount = self.configData['metricData'][self.testLevel]['TE_ISSUE_OPEN']
        self.issueInprogressCount = self.configData['metricData'][self.testLevel]['TE_ISSUE_INPROGRESS']
        self.issueClosedCount = self.configData['metricData'][self.testLevel]['TE_ISSUE_CLOSED']

        self.latestReleaseName = self.configData['metricData'][self.testLevel]['VERSION']





    def print_data(self):

        logging.info('*** Testability Review******  {} : {}'.format(self.project_name, self.reqLevel))
        logging.info('Total Requirements    : {}'.format(self.totalRequirementCount))
        logging.info('SpecOut Requirements  : {}'.format(self.specoutRequirementCount))
        logging.info('Define Requirements   : {}'.format(self.defineRequirementCount))
        logging.info('Review Requirements   : {}'.format(self.reviewRequirementCount))
        logging.info('Approved Requirements : {}'.format(self.approvedRequirementCount))
        logging.info('ETC Requirements      : {}'.format(self.etcRequirementCount))
        logging.info('****************************  {} : {}'.format(self.project_name, self.testLevel))
        logging.info('')
        logging.info('*** Test Case Development (rel : %s)', self.latestReleaseName)
        logging.info('Total Requirements    : {}'.format(self.totalRequirementCount))
        logging.info('Covered Req Items     : {}'.format(self.coveredRequirementCountOfTestcases))
        logging.info('Total Testcases       : {}'.format(self.totalTestcaseCount))
        logging.info('Covered TCs           : {}'.format(self.coveredTestcaseCountOfTestcases))
        logging.info('****************************')
        logging.info('')
        logging.info('*** Test Run ***************  {} : {}'.format(self.project_name, self.testLevel))
        logging.info('Total Requirements    : {}'.format(self.totalRequirementCount))
        logging.info('Covered Req Items     : {}'.format(self.coveredRequirementCountOfTestexecutes))
        logging.info('Uncovered Req Items   : {}'.format(self.uncoveredRequirementCountOfTestexecutes))
        logging.info('Total Testcases       : {}'.format(self.totalTestcaseCount))
        logging.info('Executed Testcase     : {}'.format(self.executedTestcaseCount))
        logging.info('Passed Count          : {}'.format(self.passCount))
        logging.info('Failed Count          : {}'.format(self.failCount))
        logging.info('NA Count              : {}'.format(self.naCount))
        logging.info('****************************')
        logging.info('')
        logging.info('*** Issues Count ***********')
        logging.info('Total Issues          : {}'.format(self.issueTotalCount))
        logging.info('Open Issues           : {}'.format(self.issueOpenCount))
        logging.info('In Progress Issues    : {}'.format(self.issueInprogressCount))
        logging.info('Closed Issues         : {}'.format(self.issueClosedCount))
        logging.info('****************************')

        # return